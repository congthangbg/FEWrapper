import thong_tin_nguoi_dung from './thong_tin_nguoi_dung';

export default thong_tin_nguoi_dung;
