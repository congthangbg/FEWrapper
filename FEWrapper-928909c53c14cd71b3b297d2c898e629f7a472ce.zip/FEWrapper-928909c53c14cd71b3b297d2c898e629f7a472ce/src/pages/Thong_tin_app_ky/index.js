import thong_tin_app_ky from './thong_tin_app_ky';

export default thong_tin_app_ky;
