import ColoredCircularProgress from "./ColoredCircularProgressComponent";

const Loading = () => {
  return (
    <>
      <ColoredCircularProgress />
    </>
  );
};
export default Loading;
